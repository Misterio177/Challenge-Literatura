package com.challengeliteratura.challengeliteratura;

import org.junit.jupiter.api.Test;

class ChallengeLiteraturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
